# Cold Outreach Email & DM Swipe File (5 Proven Templates)

Use these templates to turn GitHub issues, SaaS bottlenecks, and agency overflow into paid contracts. Keep messages under 120 words, personalize the first line, and always lead with observable proof.

---

## Template 1: The GitHub Bounty / Open-Source Maintainer Pitch

**Subject:** Re: `[Repo Name]` issue `#[Issue Number]` — quick implementation plan

Hi `[Maintainer Name]`,

I noticed `[Issue Title]` in `[Repo Name]` and dug into `[specific file/module, e.g. src/workers/retry.py]`.

I mapped out a clean fix using `[concise technical approach]` without adding extra runtime dependencies. If the `$[Bounty Amount]` bounty is still open, I can submit a tested PR within `[48 hours / 3 days]`.

Should I assign myself and open a draft PR tonight?

Best,  
`[Your Name]` | `[GitHub URL]`

---

## Template 2: SaaS Founder Automation / Speed Audit

**Subject:** Spotted a quick `[conversion / latency / workflow]` win on `[Product Name]`

Hi `[First Name]`,

Congrats on launching `[Product Name]` — `[specific genuine compliment about a feature]`.

While testing `[signup / checkout / API docs]`, I noticed `[specific friction point, e.g., manual CSV import takes ~4 steps / webhook failures aren't retried]`. Fixing that typically recovers `[X%]` drop-off or saves `[Y hrs/week]`.

I recorded a 90-second teardown showing how I'd patch it in `[tech stack]`. Mind if I send the link over?

Best,  
`[Your Name]`  
`[Portfolio / Live Project URL]`

---

## Template 3: Productized Fixed-Price Sprint Offer

**Subject:** `[2-week]` sprint to ship `[specific integration / MVP feature]`

Hi `[First Name]`,

Saw your team is hiring / looking for help with `[stack or feature from job post / X tweet]`.

Instead of a 6-week recruiting cycle, I run fixed-price `[1-2 week]` engineering sprints specifically for `[Python/TS automation, Stripe/webhook billing, internal dashboards]`.

Recent outcome: shipped `[1-line case study + measurable result]`.

Open to a 15-minute scope check this week, or should I send over a flat-rate estimate?

Thanks,  
`[Your Name]`

---

## Template 4: Agency White-Label Overflow Partner

**Subject:** Reliable `[Python / Full-Stack]` overflow capacity for `[Agency Name]`

Hi `[Agency Founder Name]`,

Love the recent `[Client / Case Study]` work `[Agency Name]` shipped.

Whenever your core team hits capacity on backend automation, API integrations, or rapid MVPs, I step in as a silent white-label senior engineer (`[Timezone]`, clean PRs, async updates, zero client-management headaches).

Happy to share 2 recent code samples and availability for this month if helpful.

Best,  
`[Your Name]` | `[GitHub / Website]`

---

## Template 5: The 3-Step Polite Follow-Up Cadence

- **Day +3 (Bump):** *"Hi `[Name]`, floating this back up in case it got buried during sprint week. Happy to send a 1-page scope breakdown if `[Project]` is still on your Q4 roadmap."*
- **Day +8 (Value Drop):** *"Hi `[Name]`, put together a quick checklist / PoC snippet for `[their problem]` — sharing here either way: `[link]`. No pressure!"*
- **Day +16 (Close Loop):** *"Hi `[Name]`, assuming `[Project]` is paused for now so I won't clutter your inbox. Reach out anytime if capacity opens up next month!"*
