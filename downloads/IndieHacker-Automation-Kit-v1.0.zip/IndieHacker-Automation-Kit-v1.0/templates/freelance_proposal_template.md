# Freelance & Consulting Project Proposal Template

> **How to use:** Replace all `[BRACKETED]` placeholders, or generate a pre-filled version directly with `python scripts/proposal_invoice_gen.py --mode proposal`.

---

**Proposal ID:** `PROP-[YEAR]-[001]`  
**Date:** `[YYYY-MM-DD]`  
**Valid Until:** `[YYYY-MM-DD]` (+14 days)  
**Prepared For:** `[Client Name]`, `[Client Title]`, `[Company Name]`  
**Prepared By:** `[Your Name / Studio]`, `[Email]`, `[Portfolio / GitHub URL]`

---

## 1. Executive Summary & Business Objective

`[Company Name]` is currently facing `[describe specific bottleneck, manual workflow, or technical debt]`, which costs the team roughly `[X hours/week or $Y/month]`.

This proposal outlines a focused **[Number]-week engineering sprint** to design, implement, and ship `[Project / Deliverable Name]`, allowing your team to `[concrete business outcome: e.g., automate reporting, cut onboarding latency by 60%, launch MVP to paying users]`.

---

## 2. Scope of Work & Deliverables

| # | Deliverable | Acceptance Criteria | Target Milestone |
| --- | --- | --- | --- |
| 1 | **Architecture & Spec** | Data flow diagram + API contract signed off | Week 1 |
| 2 | **Core Implementation** | Clean, documented codebase + automated tests | Week 2 |
| 3 | **Deployment & Handoff** | Production deploy, CI/CD checks, 30-min walkthrough | Week 3 |

### Explicit Out-of-Scope (Prevents Scope Creep)
- Features not listed in Section 2 (available via separate change order at `[Hourly Rate]/hr`)
- Third-party SaaS subscription fees or cloud hosting bills
- Ongoing 24/7 on-call SLA beyond the included 14-day bug-fix warranty

---

## 3. Investment Options (Value-Anchored)

### Option A — Essential Core (`$[Amount_A]`)
- Core feature build + unit tests + deployment README
- 7-day post-launch bug-fix warranty

### Option B — Recommended Full Delivery (`$[Amount_B]`) ⭐
- Everything in Option A
- End-to-end integration tests, monitoring/alerting hooks, and team Loom walkthrough
- 14-day post-launch bug-fix warranty + 2 async revision rounds

### Option C — Priority Sprint + 30-Day Retainer (`$[Amount_C]`)
- Everything in Option B with priority turnaround
- 30 days of post-launch optimization, tuning, and Slack/Telegram support

---

## 4. Payment Terms & Schedule

- **50% Kickoff Deposit:** Due upon proposal acceptance to reserve sprint capacity
- **50% Final Balance:** Due upon staging/production acceptance
- **Accepted Methods:** Bank Transfer / VietQR / Wise / Stripe / USDC

---

## 5. Next Steps

1. Reply to `[Your Email]` confirming Option A, B, or C.
2. Receive kickoff invoice and shared project board within 24 hours.
3. Kickoff call (`20 mins`) and repository access setup.

**Accepted By:** ___________________________ **Date:** _______________
