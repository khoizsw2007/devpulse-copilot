# Indie Hacker SaaS & Micro-Product Launch Checklist

Ship fast without missing critical revenue, security, or distribution details.

---

## Phase 1: Validation & Positioning (Before Writing Heavy Code)
- [ ] Define **1 clear ICP (Ideal Customer Profile)** and **1 painful job-to-be-done**
- [ ] Write the landing page headline + 3 bullet outcomes before finishing the backend
- [ ] Validate willingness to pay (pre-orders, waitlists, or 5 discovery DMs)
- [ ] Pick a simple pricing anchor (`$19–$49` one-time or `$15–$29/mo` starter)

## Phase 2: Product & Technical Readiness
- [ ] End-to-end happy path works cleanly on a fresh environment/incognito browser
- [ ] Error states show helpful user messages (never raw stack traces)
- [ ] Rate limiting / basic abuse protection enabled on public endpoints
- [ ] Environment secrets stored outside git (`.env` ignored, secret scan clean)
- [ ] Automated smoke test passes on main branch

## Phase 3: Checkout, Payments & Legal
- [ ] Payment links / checkout tested end-to-end (Gumroad / Lemon Squeezy / Ko-fi / VietQR)
- [ ] Instant delivery verified (buyer immediately receives ZIP / license / dashboard access)
- [ ] Support email and refund policy clearly displayed near the checkout button
- [ ] Privacy Policy & Terms of Service linked in footer

## Phase 4: High-Converting Storefront & SEO
- [ ] Clear above-the-fold CTA + real product screenshot / CLI output demo
- [ ] OpenGraph (`og:title`, `og:description`, `og:image`) tags verified for social sharing
- [ ] Social proof / live demo / sample output included so buyers trust quality
- [ ] Fast mobile load time (no bloated scripts)

## Phase 5: Launch Day Distribution
- [ ] **X / Twitter:** Publish launch thread (Problem -> Demo GIF/Screenshot -> How it works -> Link)
- [ ] **Reddit:** Post genuine story + lessons learned on `r/SideProject` & `r/indiehackers` (respect self-promo rules)
- [ ] **Directories:** Submit to Product Hunt, Hacker News (`Show HN`), DevHunt, and Indie Hackers
- [ ] **Direct Outreach:** DM 15 warm contacts / past collaborators with an early-bird discount

## Phase 6: Post-Launch (Days 1–14)
- [ ] Reply to every comment, bug report, and buyer email within 4 hours
- [ ] Ship a `v1.0.1` quick-fix update based on the first 5 buyers' feedback
- [ ] Collect 2–3 short testimonials and add them directly above the checkout button
