# Full-Stack Indie Hacker & Bounty Automation Starter Kit (v1.0) — Buyer Guide

Welcome! Thank you for picking up the **Full-Stack Indie Hacker & Bounty Automation Starter Kit (v1.0)**.

Everything in this kit is built for speed, portability, and zero setup friction:
- **Zero third-party Python dependencies** — every CLI script runs on Python 3.9+ using only the standard library.
- **Battle-tested business templates** — proposal, outreach, and launch checklists ready to copy, customize, and close clients.

---

## Package Structure

```text
IndieHacker-Automation-Kit-v1.0/
├── README_BUYER_GUIDE.md
├── CREATOR_LICENSE.txt
├── scripts/
│   ├── bounty_monitor.py          # GitHub Issue & Bounty Monitor CLI
│   ├── freelance_pricing_calc.py  # Freelance ROI & Pricing Calculator CLI
│   └── proposal_invoice_gen.py    # Markdown Invoice & Proposal Generator CLI
└── templates/
    ├── freelance_proposal_template.md
    ├── cold_outreach_emails.md
    └── saas_launch_checklist.md
```

---

## 1. Prerequisites

Check that Python 3.9+ is installed:

```bash
python --version
```

No `pip install` required.

---

## 2. Script Guides & Quickstart Commands

### A. `scripts/bounty_monitor.py` — GitHub Bounty & Issue Monitor

Find open paid bounties, funded OSS issues, and low-competition `help wanted` tickets directly from your terminal or export them to Markdown/JSON.

**Offline smoke test (demo data):**
```bash
python scripts/bounty_monitor.py --demo --format table
```

**Live GitHub search (Python bounties created in the last 60 days):**
```bash
python scripts/bounty_monitor.py --labels bounty --language python --days 60 --limit 20
```

**Export a daily Markdown digest (optional `GITHUB_TOKEN` increases rate limits):**
```bash
export GITHUB_TOKEN=ghp_your_token_here   # Windows PowerShell: $env:GITHUB_TOKEN="ghp_..."
python scripts/bounty_monitor.py --query "bounty OR algora OR reward" --max-comments 5 --format markdown --out bounties.md
```

---

### B. `scripts/freelance_pricing_calc.py` — Pricing & ROI Calculator

Stop undercharging. Convert your target annual net income, overhead, taxes, and non-billable time into defendable hourly rates, 3-tier fixed quotes, and client ROI payback metrics.

**Calculate rates + a 40-hour project quote:**
```bash
python scripts/freelance_pricing_calc.py \
  --target-income 72000 \
  --expenses 4800 \
  --tax-rate 0.22 \
  --project-hours 40 \
  --client-monthly-gain 4000
```

**Output as Markdown table for pasting into a proposal:**
```bash
python scripts/freelance_pricing_calc.py --target-income 60000 --project-hours 30 --format markdown
```

---

### C. `scripts/proposal_invoice_gen.py` — Invoice & Proposal Generator

Generate clean Markdown invoices and proposals from CLI flags or a reusable JSON job file (which you can convert to PDF via VS Code, Obsidian, Pandoc, or Typora).

**1. Generate a quick invoice from CLI flags:**
```bash
python scripts/proposal_invoice_gen.py \
  --mode invoice \
  --doc-id INV-2026-010 \
  --sender "Your Studio" \
  --sender-email "you@example.com" \
  --client "Acme Labs" \
  --project "Webhook Automation" \
  --item "Backend Integration:1200" \
  --item "Automated Tests & Docs:400" \
  --out INV-2026-010.md
```

**2. Use a JSON config for recurring clients:**
```bash
python scripts/proposal_invoice_gen.py --init-sample job.json
python scripts/proposal_invoice_gen.py --mode proposal --config job.json --out proposal_acme.md
```

---

## 3. Customizing the Templates (`templates/`)

1. **`freelance_proposal_template.md`**: Pair with `freelance_pricing_calc.py` output to send 3-tier proposals (Essential / Recommended / Priority) in under 10 minutes.
2. **`cold_outreach_emails.md`**: Use Template 1 right after finding a fresh issue with `bounty_monitor.py` so you pitch maintainers before 10 other developers jump in.
3. **`saas_launch_checklist.md`**: Run through Phases 1–6 before launching your next micro-SaaS, developer tool, or Gumroad product.

---

## 4. Suggested Weekly Workflow

1. **Monday (15 mins):** Run `bounty_monitor.py` and pick 3 high-fit issues or founder bottlenecks.
2. **Tuesday:** Send 3 personalized pitches using `cold_outreach_emails.md`.
3. **Wednesday:** Price qualified leads with `freelance_pricing_calc.py` and generate proposals with `proposal_invoice_gen.py`.
4. **Friday:** Ship deliverables, issue invoices, and check off your next micro-product launch items.

---

## 5. License & Support

See `CREATOR_LICENSE.txt` included in this package for your single-seat commercial usage rights and creator contact details.
