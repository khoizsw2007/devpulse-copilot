#!/usr/bin/env python3
"""
GitHub Issue & Bounty Monitor CLI
---------------------------------
Zero-dependency CLI tool (Python standard library only) for indie hackers and
freelance developers to discover paid GitHub bounties, funded OSS issues, and
high-signal "help wanted" opportunities.

Usage examples:
    python bounty_monitor.py --labels bounty,paid --language python --limit 15
    python bounty_monitor.py --query "algora OR bounty OR $100" --min-comments 1
    python bounty_monitor.py --demo --format markdown --out bounties.md
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


GITHUB_SEARCH_URL = "https://api.github.com/search/issues"

DEMO_ISSUES: list[dict[str, Any]] = [
    {
        "title": "[Bounty $450] Add async webhook retry queue with exponential backoff",
        "html_url": "https://github.com/example-oss/webhook-relay/issues/142",
        "repository_url": "https://api.github.com/repos/example-oss/webhook-relay",
        "state": "open",
        "comments": 4,
        "created_at": "2026-10-28T11:20:00Z",
        "updated_at": "2026-11-10T08:15:00Z",
        "labels": [{"name": "bounty"}, {"name": "python"}, {"name": "help wanted"}],
        "user": {"login": "maintainer-alex"},
        "body": "Looking for a clean asyncio implementation with unit tests. Reward: $450 via Algora.",
    },
    {
        "title": "Implement CSV & Parquet streaming exporter ($250 reward)",
        "html_url": "https://github.com/example-data/fast-etl/issues/89",
        "repository_url": "https://api.github.com/repos/example-data/fast-etl",
        "state": "open",
        "comments": 2,
        "created_at": "2026-11-02T14:05:00Z",
        "updated_at": "2026-11-11T16:40:00Z",
        "labels": [{"name": "bounty"}, {"name": "enhancement"}],
        "user": {"login": "data-lead"},
        "body": "Need memory-bounded streaming export for large tables. $250 USDC or GitHub Sponsors.",
    },
    {
        "title": "Fix OAuth2 PKCE token refresh race condition in TypeScript SDK",
        "html_url": "https://github.com/example-auth/sdk-ts/issues/311",
        "repository_url": "https://api.github.com/repos/example-auth/sdk-ts",
        "state": "open",
        "comments": 6,
        "created_at": "2026-11-05T09:00:00Z",
        "updated_at": "2026-11-12T12:10:00Z",
        "labels": [{"name": "bug"}, {"name": "paid"}, {"name": "typescript"}],
        "user": {"login": "sec-ops"},
        "body": "Concurrent requests trigger duplicate refresh calls. $300 bounty upon merged PR.",
    },
]


def extract_repo_name(repository_url: str) -> str:
    """Extract 'owner/repo' from a GitHub API repository URL."""
    parts = repository_url.rstrip("/").split("/")
    if len(parts) >= 2:
        return f"{parts[-2]}/{parts[-1]}"
    return repository_url


def build_search_query(
    query: str,
    labels: list[str],
    language: str | None,
    state: str,
    days_back: int | None,
) -> str:
    """Construct a GitHub issue search query string."""
    terms = ["is:issue", f"is:{state}"]
    if query.strip():
        terms.append(query.strip())
    for label in labels:
        clean = label.strip()
        if clean:
            if " " in clean:
                terms.append(f'label:"{clean}"')
            else:
                terms.append(f"label:{clean}")
    if language:
        terms.append(f"language:{language.strip()}")
    if days_back and days_back > 0:
        cutoff = datetime.now(timezone.utc).timestamp() - (days_back * 86400)
        cutoff_iso = datetime.fromtimestamp(cutoff, tz=timezone.utc).strftime("%Y-%m-%d")
        terms.append(f"created:>={cutoff_iso}")
    return " ".join(terms)


def fetch_github_issues(
    search_query: str,
    limit: int,
    sort: str,
    token: str | None,
) -> list[dict[str, Any]]:
    """Query the GitHub Search Issues API using urllib."""
    params = urllib.parse.urlencode(
        {
            "q": search_query,
            "sort": sort,
            "order": "desc",
            "per_page": max(1, min(limit, 100)),
        }
    )
    url = f"{GITHUB_SEARCH_URL}?{params}"
    headers = {
        "Accept": "application/vnd.github+json",
        "User-Agent": "IndieHacker-Bounty-Monitor/1.0",
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"

    req = urllib.request.Request(url, headers=headers, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
            return payload.get("items", [])
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"GitHub API HTTP {exc.code}: {body[:300]}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Network error contacting GitHub API: {exc.reason}") from exc


def normalize_issues(
    raw_items: list[dict[str, Any]],
    min_comments: int,
    max_comments: int | None,
) -> list[dict[str, Any]]:
    """Filter and normalize GitHub issue payloads into compact records."""
    normalized: list[dict[str, Any]] = []
    for item in raw_items:
        comments = int(item.get("comments", 0))
        if comments < min_comments:
            continue
        if max_comments is not None and comments > max_comments:
            continue
        labels = [lbl.get("name", "") for lbl in item.get("labels", []) if lbl.get("name")]
        normalized.append(
            {
                "repo": extract_repo_name(item.get("repository_url", "")),
                "title": item.get("title", "").strip(),
                "url": item.get("html_url", ""),
                "labels": labels,
                "comments": comments,
                "created_at": item.get("created_at", "")[:10],
                "updated_at": item.get("updated_at", "")[:10],
                "author": (item.get("user") or {}).get("login", "unknown"),
            }
        )
    return normalized


def format_table(issues: list[dict[str, Any]]) -> str:
    """Format normalized issues as an aligned terminal table."""
    if not issues:
        return "No matching issues found."
    lines = [
        f"Found {len(issues)} issue(s):",
        "-" * 96,
        f"{'REPO':<28} {'CMT':>3}  {'CREATED':<10} {'LABELS':<22} TITLE",
        "-" * 96,
    ]
    for item in issues:
        repo = item["repo"][:27]
        labels = ",".join(item["labels"][:3])[:21]
        title = item["title"][:60]
        lines.append(
            f"{repo:<28} {item['comments']:>3}  {item['created_at']:<10} {labels:<22} {title}"
        )
        lines.append(f"  -> {item['url']}")
    return "\n".join(lines)


def format_markdown(issues: list[dict[str, Any]], search_query: str) -> str:
    """Format normalized issues as a Markdown report."""
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    lines = [
        f"# GitHub Bounty & Issue Digest",
        f"",
        f"- **Generated:** {now}",
        f"- **Query:** `{search_query}`",
        f"- **Matches:** {len(issues)}",
        "",
    ]
    if not issues:
        lines.append("_No matching issues found._")
        return "\n".join(lines)

    lines.append("| Repository | Title | Labels | Comments | Created |")
    lines.append("| --- | --- | --- | ---: | --- |")
    for item in issues:
        safe_title = item["title"].replace("|", "\\|")
        labels = ", ".join(f"`{l}`" for l in item["labels"][:4]) or "-"
        lines.append(
            f"| `{item['repo']}` | [{safe_title}]({item['url']}) | {labels} | {item['comments']} | {item['created_at']} |"
        )
    return "\n".join(lines)


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Monitor GitHub for paid bounties and high-signal open-source issues."
    )
    parser.add_argument(
        "--query",
        default="bounty OR reward OR algora",
        help='Free-text GitHub search terms (default: "bounty OR reward OR algora").',
    )
    parser.add_argument(
        "--labels",
        default="bounty",
        help='Comma-separated GitHub labels to require (default: "bounty"). Use "" for none.',
    )
    parser.add_argument("--language", default=None, help="Filter by programming language (e.g. python, typescript).")
    parser.add_argument("--state", choices=["open", "closed"], default="open", help="Issue state (default: open).")
    parser.add_argument("--days", type=int, default=90, help="Only include issues created in the last N days (0=any).")
    parser.add_argument("--min-comments", type=int, default=0, help="Minimum comment count.")
    parser.add_argument("--max-comments", type=int, default=None, help="Maximum comment count (find less crowded issues).")
    parser.add_argument("--sort", choices=["created", "updated", "comments"], default="updated", help="GitHub sort order.")
    parser.add_argument("--limit", type=int, default=15, help="Max results to fetch (1-100).")
    parser.add_argument("--token", default=os.environ.get("GITHUB_TOKEN"), help="GitHub PAT (or set GITHUB_TOKEN env var).")
    parser.add_argument("--format", choices=["table", "json", "markdown"], default="table", help="Output format.")
    parser.add_argument("--out", type=Path, default=None, help="Optional file path to save output.")
    parser.add_argument(
        "--demo",
        action="store_true",
        help="Run using built-in sample issues (offline mode, no GitHub API call).",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    labels = [x.strip() for x in args.labels.split(",") if x.strip()] if args.labels else []
    search_query = build_search_query(
        query=args.query,
        labels=labels,
        language=args.language,
        state=args.state,
        days_back=args.days if args.days > 0 else None,
    )

    if args.demo:
        raw_items = DEMO_ISSUES[: args.limit]
    else:
        try:
            raw_items = fetch_github_issues(
                search_query=search_query,
                limit=args.limit,
                sort=args.sort,
                token=args.token,
            )
        except RuntimeError as exc:
            print(f"[ERROR] {exc}", file=sys.stderr)
            print("Tip: Pass --demo for offline testing or set GITHUB_TOKEN for higher rate limits.", file=sys.stderr)
            return 1

    issues = normalize_issues(raw_items, min_comments=args.min_comments, max_comments=args.max_comments)

    if args.format == "json":
        output = json.dumps({"query": search_query, "count": len(issues), "issues": issues}, indent=2)
    elif args.format == "markdown":
        output = format_markdown(issues, search_query)
    else:
        output = format_table(issues)

    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(output + "\n", encoding="utf-8")
        print(f"Saved {len(issues)} issue(s) to {args.out}")
    else:
        print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
