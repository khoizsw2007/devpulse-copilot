#!/usr/bin/env python3
"""
Markdown Invoice & Client Proposal Generator CLI
------------------------------------------------
Zero-dependency CLI tool (Python standard library only) for generating clean,
client-ready Markdown invoices and project proposals from CLI flags or JSON.

Usage examples:
    python proposal_invoice_gen.py --init-sample sample_job.json
    python proposal_invoice_gen.py --mode invoice --config sample_job.json --out INV-2026-001.md
    python proposal_invoice_gen.py --mode proposal --client "Acme Labs" --project "API Automation" --item "Backend API:1200" --item "Admin Dashboard:800"
"""

from __future__ import annotations

import argparse
import json
from datetime import date, timedelta
from pathlib import Path
from typing import Any


SAMPLE_JOB_CONFIG: dict[str, Any] = {
    "doc_id": "INV-2026-001",
    "currency": "USD",
    "tax_percent": 0.0,
    "discount_percent": 0.0,
    "deposit_percent": 50.0,
    "due_days": 14,
    "sender": {
        "name": "Alex Nguyen Studio",
        "email": "alex@example.com",
        "website": "https://github.com/your-handle",
        "payment_notes": "Wire / VietQR / Wise / USDC (Polygon/Solana) accepted.",
    },
    "client": {
        "company": "Acme SaaS Inc.",
        "contact": "Jordan Lee",
        "email": "jordan@acmesaas.example",
    },
    "project": {
        "title": "GitHub Webhook & Billing Automation Pipeline",
        "summary": "Design, build, and deploy an automated webhook ingestion and invoice sync worker with unit tests and runbook.",
        "timeline_days": 14,
    },
    "items": [
        {"description": "System architecture & API integration", "qty": 1, "unit_price": 900.0},
        {"description": "Automated worker & retry queue + tests", "qty": 1, "unit_price": 1200.0},
        {"description": "Deployment docs & 14-day warranty", "qty": 1, "unit_price": 400.0},
    ],
}


def parse_item_spec(spec: str) -> dict[str, Any]:
    """Parse 'Description:Amount' or 'Description:Qty:UnitPrice' CLI item specs."""
    parts = [p.strip() for p in spec.split(":")]
    if len(parts) == 2:
        return {"description": parts[0], "qty": 1, "unit_price": float(parts[1])}
    if len(parts) == 3:
        return {"description": parts[0], "qty": float(parts[1]), "unit_price": float(parts[2])}
    raise ValueError(f"Invalid --item format '{spec}'. Use 'Description:Amount' or 'Description:Qty:UnitPrice'.")


def compute_totals(data: dict[str, Any]) -> dict[str, float]:
    """Calculate subtotal, discount, tax, total, and deposit amount."""
    subtotal = sum(float(i["qty"]) * float(i["unit_price"]) for i in data["items"])
    discount_pct = float(data.get("discount_percent", 0.0))
    tax_pct = float(data.get("tax_percent", 0.0))
    deposit_pct = float(data.get("deposit_percent", 50.0))

    discount_amt = subtotal * (discount_pct / 100.0)
    taxable = subtotal - discount_amt
    tax_amt = taxable * (tax_pct / 100.0)
    total = taxable + tax_amt
    deposit_amt = total * (deposit_pct / 100.0)

    return {
        "subtotal": round(subtotal, 2),
        "discount": round(discount_amt, 2),
        "tax": round(tax_amt, 2),
        "total": round(total, 2),
        "deposit": round(deposit_amt, 2),
        "balance": round(total - deposit_amt, 2),
    }


def render_invoice(data: dict[str, Any]) -> str:
    """Render a clean Markdown invoice."""
    today = date.today()
    due = today + timedelta(days=int(data.get("due_days", 14)))
    c = data.get("currency", "USD")
    totals = compute_totals(data)
    sender = data["sender"]
    client = data["client"]
    project = data["project"]

    lines = [
        f"# INVOICE `{data['doc_id']}`",
        "",
        f"**Issue Date:** {today.isoformat()}  ",
        f"**Due Date:** {due.isoformat()}  ",
        f"**Project:** {project['title']}",
        "",
        "---",
        "",
        "| From | Bill To |",
        "| --- | --- |",
        f"| **{sender['name']}**<br>{sender['email']}<br>{sender.get('website', '')} | **{client['company']}**<br>Attn: {client.get('contact', '')}<br>{client.get('email', '')} |",
        "",
        "## Line Items",
        "",
        "| Description | Qty | Unit Price | Amount |",
        "| --- | ---: | ---: | ---: |",
    ]
    for item in data["items"]:
        qty = float(item["qty"])
        unit = float(item["unit_price"])
        amt = qty * unit
        lines.append(f"| {item['description']} | {qty:g} | {c} {unit:,.2f} | {c} {amt:,.2f} |")

    lines.extend(
        [
            "",
            "## Summary",
            f"- **Subtotal:** {c} {totals['subtotal']:,.2f}",
            f"- **Discount ({data.get('discount_percent', 0)}%):** -{c} {totals['discount']:,.2f}",
            f"- **Tax ({data.get('tax_percent', 0)}%):** {c} {totals['tax']:,.2f}",
            f"- **Total Due:** **{c} {totals['total']:,.2f}**",
            "",
            "## Payment Instructions",
            sender.get("payment_notes", "Please remit payment by the due date."),
            "",
            "_Thank you for your business!_",
        ]
    )
    return "\n".join(lines)


def render_proposal(data: dict[str, Any]) -> str:
    """Render a client-ready Markdown project proposal."""
    today = date.today()
    valid_until = today + timedelta(days=int(data.get("due_days", 14)))
    c = data.get("currency", "USD")
    totals = compute_totals(data)
    sender = data["sender"]
    client = data["client"]
    project = data["project"]
    deposit_pct = float(data.get("deposit_percent", 50.0))

    lines = [
        f"# PROJECT PROPOSAL: {project['title']}",
        "",
        f"**Prepared For:** {client['company']} ({client.get('contact', 'Team')})  ",
        f"**Prepared By:** {sender['name']} ({sender['email']})  ",
        f"**Date:** {today.isoformat()} | **Valid Until:** {valid_until.isoformat()}",
        "",
        "## 1. Executive Summary",
        project.get("summary", "Deliver production-ready engineering work aligned to business milestones."),
        "",
        "## 2. Scope & Investment",
        "",
        "| Deliverable | Qty | Unit | Total |",
        "| --- | ---: | ---: | ---: |",
    ]
    for item in data["items"]:
        qty = float(item["qty"])
        unit = float(item["unit_price"])
        amt = qty * unit
        lines.append(f"| {item['description']} | {qty:g} | {c} {unit:,.2f} | {c} {amt:,.2f} |")

    lines.extend(
        [
            "",
            f"**Total Project Investment:** **{c} {totals['total']:,.2f}**",
            "",
            "## 3. Timeline & Payment Schedule",
            f"- **Estimated Delivery:** {project.get('timeline_days', 14)} calendar days from kickoff",
            f"- **Kickoff Deposit ({deposit_pct:g}%):** {c} {totals['deposit']:,.2f}",
            f"- **Final Milestone ({100 - deposit_pct:g}%):** {c} {totals['balance']:,.2f} upon delivery acceptance",
            "",
            "## 4. Next Steps",
            f"Reply to **{sender['email']}** to confirm scope and receive the kickoff invoice.",
        ]
    )
    return "\n".join(lines)


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate Markdown invoices and client proposals.")
    parser.add_argument("--mode", choices=["invoice", "proposal"], default="invoice", help="Document type.")
    parser.add_argument("--config", type=Path, default=None, help="Path to JSON job config file.")
    parser.add_argument("--init-sample", type=Path, default=None, help="Write a sample JSON config and exit.")
    parser.add_argument("--doc-id", default="INV-2026-001", help="Invoice or proposal ID.")
    parser.add_argument("--sender", default="Indie Studio", help="Your name or studio.")
    parser.add_argument("--sender-email", default="hello@example.com", help="Your email.")
    parser.add_argument("--client", default="Client Co.", help="Client company name.")
    parser.add_argument("--project", default="Automation & Engineering Sprint", help="Project title.")
    parser.add_argument("--currency", default="USD", help="Currency code.")
    parser.add_argument("--tax", type=float, default=0.0, help="Tax percentage (e.g. 10 for 10%).")
    parser.add_argument("--discount", type=float, default=0.0, help="Discount percentage.")
    parser.add_argument("--deposit", type=float, default=50.0, help="Deposit percentage for proposals.")
    parser.add_argument("--due-days", type=int, default=14, help="Days until due/expiration.")
    parser.add_argument(
        "--item",
        action="append",
        default=[],
        help="Line item as 'Description:Amount' or 'Description:Qty:UnitPrice'. Repeatable.",
    )
    parser.add_argument("--out", type=Path, default=None, help="Output Markdown file path.")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    if args.init_sample:
        args.init_sample.parent.mkdir(parents=True, exist_ok=True)
        args.init_sample.write_text(json.dumps(SAMPLE_JOB_CONFIG, indent=2) + "\n", encoding="utf-8")
        print(f"Wrote sample config to {args.init_sample}")
        return 0

    if args.config:
        data = json.loads(args.config.read_text(encoding="utf-8"))
    else:
        items = [parse_item_spec(s) for s in args.item] if args.item else SAMPLE_JOB_CONFIG["items"]
        data = {
            "doc_id": args.doc_id,
            "currency": args.currency,
            "tax_percent": args.tax,
            "discount_percent": args.discount,
            "deposit_percent": args.deposit,
            "due_days": args.due_days,
            "sender": {
                "name": args.sender,
                "email": args.sender_email,
                "website": "",
                "payment_notes": "Remit via bank transfer, VietQR, Wise, or USDC.",
            },
            "client": {"company": args.client, "contact": "Project Lead", "email": ""},
            "project": {
                "title": args.project,
                "summary": "Custom implementation, automated testing, and deployment documentation.",
                "timeline_days": 14,
            },
            "items": items,
        }

    rendered = render_invoice(data) if args.mode == "invoice" else render_proposal(data)
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(rendered + "\n", encoding="utf-8")
        print(f"Generated {args.mode} at {args.out}")
    else:
        print(rendered)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
