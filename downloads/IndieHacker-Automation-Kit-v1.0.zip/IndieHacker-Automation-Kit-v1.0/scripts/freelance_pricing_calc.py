#!/usr/bin/env python3
"""
Freelance ROI & Hourly/Fixed Pricing Calculator CLI
---------------------------------------------------
Zero-dependency CLI tool (Python standard library only) that converts your
income target, overhead, taxes, and non-billable hours into:
  1. Required minimum & target hourly rates
  2. Risk-adjusted fixed-price project quotes
  3. Three-tier value-based pricing options (Starter / Growth / VIP)
  4. Client ROI & payback-period analysis to justify your quote

Usage examples:
    python freelance_pricing_calc.py --target-income 72000 --tax-rate 0.22 --hours 35
    python freelance_pricing_calc.py --target-income 60000 --project-hours 40 --client-monthly-gain 4500 --format markdown
"""

from __future__ import annotations

import argparse
import json
import math
from typing import Any


def calculate_pricing(
    target_net_income: float,
    annual_expenses: float,
    tax_rate: float,
    weeks_per_year: int,
    hours_per_week: float,
    billable_ratio: float,
    project_hours: float,
    scope_buffer: float,
    currency: str,
    client_monthly_gain: float,
) -> dict[str, Any]:
    """Compute freelance hourly rate, fixed quote, tiered packages, and client ROI."""
    if not (0.0 <= tax_rate < 0.9):
        raise ValueError("tax_rate must be between 0.0 and 0.89")
    if not (0.1 <= billable_ratio <= 1.0):
        raise ValueError("billable_ratio must be between 0.1 and 1.0")
    if weeks_per_year <= 0 or hours_per_week <= 0 or project_hours <= 0:
        raise ValueError("weeks_per_year, hours_per_week, and project_hours must be positive")

    gross_needed = (target_net_income + annual_expenses) / (1.0 - tax_rate)
    total_work_hours = weeks_per_year * hours_per_week
    billable_hours = total_work_hours * billable_ratio

    min_hourly = gross_needed / billable_hours
    # Round up cleanly to nearest 5 for market-ready quoting
    recommended_hourly = math.ceil(min_hourly * 1.15 / 5.0) * 5.0

    buffered_hours = project_hours * (1.0 + scope_buffer)
    fixed_base = recommended_hourly * buffered_hours
    fixed_quote = math.ceil(fixed_base / 50.0) * 50.0

    tiers = {
        "essential": round(fixed_quote * 0.85, 2),
        "recommended": round(fixed_quote, 2),
        "priority_retainer": round(fixed_quote * 1.45, 2),
    }

    roi_summary: dict[str, Any] = {}
    if client_monthly_gain > 0:
        payback_months = fixed_quote / client_monthly_gain
        annual_client_value = client_monthly_gain * 12.0
        roi_percent = ((annual_client_value - fixed_quote) / fixed_quote) * 100.0
        roi_summary = {
            "client_monthly_gain": round(client_monthly_gain, 2),
            "annual_client_value": round(annual_client_value, 2),
            "payback_months": round(payback_months, 2),
            "first_year_roi_percent": round(roi_percent, 1),
        }

    return {
        "currency": currency,
        "inputs": {
            "target_net_income": target_net_income,
            "annual_expenses": annual_expenses,
            "tax_rate": tax_rate,
            "weeks_per_year": weeks_per_year,
            "hours_per_week": hours_per_week,
            "billable_ratio": billable_ratio,
            "project_hours": project_hours,
            "scope_buffer": scope_buffer,
        },
        "rates": {
            "gross_revenue_needed": round(gross_needed, 2),
            "annual_billable_hours": round(billable_hours, 1),
            "break_even_hourly": round(min_hourly, 2),
            "recommended_hourly": recommended_hourly,
        },
        "project_quote": {
            "estimated_hours": project_hours,
            "buffered_hours": round(buffered_hours, 1),
            "fixed_quote": fixed_quote,
            "deposit_50_percent": round(fixed_quote * 0.5, 2),
            "tiers": tiers,
        },
        "client_roi": roi_summary,
    }


def format_text(result: dict[str, Any]) -> str:
    """Render pricing report as clean plain text."""
    c = result["currency"]
    r = result["rates"]
    q = result["project_quote"]
    lines = [
        "=== Freelance Pricing & ROI Breakdown ===",
        f"Gross Revenue Needed : {c} {r['gross_revenue_needed']:,.2f} / yr",
        f"Annual Billable Hours: {r['annual_billable_hours']:,.1f} hrs",
        f"Break-even Hourly    : {c} {r['break_even_hourly']:,.2f} / hr",
        f"Recommended Hourly   : {c} {r['recommended_hourly']:,.2f} / hr (includes 15% profit margin)",
        "",
        "--- Fixed-Price Project Quote ---",
        f"Buffered Effort      : {q['buffered_hours']} hrs (base {q['estimated_hours']} hrs)",
        f"Standard Fixed Quote : {c} {q['fixed_quote']:,.2f}",
        f"50% Upfront Deposit  : {c} {q['deposit_50_percent']:,.2f}",
        "",
        "--- 3-Tier Proposal Anchors ---",
        f"1. Essential (Core Scope)        : {c} {q['tiers']['essential']:,.2f}",
        f"2. Recommended (Full Delivery)   : {c} {q['tiers']['recommended']:,.2f}",
        f"3. Priority + 30d Support        : {c} {q['tiers']['priority_retainer']:,.2f}",
    ]
    roi = result["client_roi"]
    if roi:
        lines.extend(
            [
                "",
                "--- Client ROI Justification ---",
                f"Estimated Monthly Gain: {c} {roi['client_monthly_gain']:,.2f}/mo",
                f"12-Month Client Value : {c} {roi['annual_client_value']:,.2f}",
                f"Payback Period        : {roi['payback_months']} months",
                f"First-Year Client ROI : {roi['first_year_roi_percent']}%",
            ]
        )
    return "\n".join(lines)


def format_markdown(result: dict[str, Any]) -> str:
    """Render pricing report as Markdown."""
    c = result["currency"]
    r = result["rates"]
    q = result["project_quote"]
    lines = [
        "# Freelance Pricing & ROI Estimate",
        "",
        "## Annual Rate Baseline",
        f"- **Gross Revenue Needed:** {c} {r['gross_revenue_needed']:,.2f}",
        f"- **Annual Billable Hours:** {r['annual_billable_hours']:,.1f} hrs",
        f"- **Break-Even Hourly Rate:** {c} {r['break_even_hourly']:,.2f}/hr",
        f"- **Recommended Hourly Rate:** {c} {r['recommended_hourly']:,.2f}/hr",
        "",
        "## Project Quote Options",
        "",
        "| Tier | Scope Focus | Price |",
        "| --- | --- | ---: |",
        f"| **Essential** | Core deliverables only | {c} {q['tiers']['essential']:,.2f} |",
        f"| **Recommended** | Full scope + QA + handoff | {c} {q['tiers']['recommended']:,.2f} |",
        f"| **Priority + Support** | Expedited delivery + 30-day warranty | {c} {q['tiers']['priority_retainer']:,.2f} |",
    ]
    roi = result["client_roi"]
    if roi:
        lines.extend(
            [
                "",
                "## Client ROI Summary",
                f"- **Client Monthly Gain:** {c} {roi['client_monthly_gain']:,.2f}",
                f"- **Payback Period:** {roi['payback_months']} months",
                f"- **First-Year ROI:** {roi['first_year_roi_percent']}%",
            ]
        )
    return "\n".join(lines)


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Calculate sustainable freelance hourly rates, fixed quotes, and client ROI."
    )
    parser.add_argument("--target-income", type=float, default=60000.0, help="Target annual take-home income.")
    parser.add_argument("--expenses", type=float, default=4800.0, help="Annual business overhead (software, gear).")
    parser.add_argument("--tax-rate", type=float, default=0.20, help="Effective tax reserve ratio (e.g. 0.20 for 20%).")
    parser.add_argument("--weeks", type=int, default=46, help="Working weeks per year (default: 46).")
    parser.add_argument("--hours", type=float, default=35.0, help="Total work hours per week (default: 35).")
    parser.add_argument(
        "--billable-ratio",
        type=float,
        default=0.65,
        help="Fraction of work hours that are billable (default: 0.65).",
    )
    parser.add_argument("--project-hours", type=float, default=40.0, help="Estimated raw hours for target project.")
    parser.add_argument("--scope-buffer", type=float, default=0.20, help="Contingency buffer (default: 0.20 = 20%).")
    parser.add_argument(
        "--client-monthly-gain",
        type=float,
        default=2500.0,
        help="Estimated monthly value/savings generated for client (0 to skip ROI).",
    )
    parser.add_argument("--currency", default="USD", help="Currency label (e.g. USD, VND, EUR).")
    parser.add_argument("--format", choices=["text", "json", "markdown"], default="text", help="Output format.")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    result = calculate_pricing(
        target_net_income=args.target_income,
        annual_expenses=args.expenses,
        tax_rate=args.tax_rate,
        weeks_per_year=args.weeks,
        hours_per_week=args.hours,
        billable_ratio=args.billable_ratio,
        project_hours=args.project_hours,
        scope_buffer=args.scope_buffer,
        currency=args.currency,
        client_monthly_gain=args.client_monthly_gain,
    )
    if args.format == "json":
        print(json.dumps(result, indent=2))
    elif args.format == "markdown":
        print(format_markdown(result))
    else:
        print(format_text(result))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
